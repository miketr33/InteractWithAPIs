﻿using APIInteraction;

namespace UnitTests;

/// <summary>
/// This class contains a number of unit tests to test the Communications class. 
/// </summary>
[TestFixture]
public class CommsUnitTests
{
    [SetUp]
    public void Setup()
    {

    }

    /// <summary>
    /// Tests if when an artist name is passed, that the MusicBrainz API responds with the expected Guid.
    /// Note: If this fails, it may be due to MusicBrainz changing the ID (although unlikely).
    /// To test this, use Postman to manually submit the following request: http://musicbrainz.org/ws/2/artist/?query=artist:the%20beatles&limit=1
    /// and see if the expected Id is still returned. If the Id is different this test may need updating. 
    /// </summary>
    /// <returns></returns>
    [Test]
    public async Task GetArtistIdFromArtistNameUsingMusicBrainzAPIAsync()
    {
        var artistName = "the beatles";
        Guid expectedId = new("b10bbbfc-cf9e-42e0-be17-e2c3e1d2600d");
        Communications comms = new();
        var id = await comms.GetArtistId(artistName);

        Assert.That(id, Is.EqualTo(expectedId));
    }


    /// <summary>
    /// Tests that if you pass an invalid artist name, that the function returns null.
    /// </summary>
    /// <returns></returns>
    [Test]
    public async Task GetArtistIdNullFromArtistNameUsingMusicBrainzAPIAsyncPassingFakeArtist()
    {
        var artistName = "SOMEFAKEARTIST";
        Communications comms = new();
        var id = await comms.GetArtistId(artistName);

        Assert.That(id, Is.EqualTo(null));
    }

    /// <summary>
    /// Tests that when an artist id (in this case the id for Queen) is passed.
    /// The GetReleasesByArtistId get's the correct releases.
    /// Note: If this test fails, use Postman to submit a manual request: https://musicbrainz.org/ws/2/work?artist=0383dadf-2a4e-4d10-a46a-e9e041da8eb3&fmt=json
    /// This will allow you to check if the response data has changed on the MusicBrainz API.
    /// </summary>
    [Test]
    public async Task GetReleasesByArtistIdUsingMusicBrainzAPIAsync()
    {
        Guid artistId = new("0383dadf-2a4e-4d10-a46a-e9e041da8eb3");
        Communications comms = new();
        List<string> releases = await comms.GetWorksByArtistId(artistId);
        Assert.Multiple(() =>
        {
            Assert.That(releases.Any(r => r == "April Lady"));
            Assert.That(releases.Any(r => r == "A Human Body"));
            Assert.That(releases.Any(r => r == "Be‐Bop‐a‐Lula"));
            Assert.That(releases.Any(r => r == "(You’re So Square) Baby I Don’t Care"));
            Assert.That(releases.Any(r => r == "A Winter’s Tale"));
        });
    }

    /// <summary>
    /// Checks that when no releases are found (because the Guid (artist id) that has been passed does not relate to
    /// any artist on the APIs database), that the list is returned empty.
    /// </summary>
    /// <returns></returns>
    [Test]
    public async Task AssertNullReturnedIfFakeIDUsedToRetreiveReleasesMusicBrainzAPI()
    {
        Guid artistId = new("aebbc63d-9865-4ce6-81b1-20e5f79358f9");    // This a real guid, but is does not relate to a real artist
        Communications comms = new();

        List<string> releases = await comms.GetWorksByArtistId(artistId);

        Assert.That(releases.Count, Is.EqualTo(0));
    }

    /// <summary>
    /// Tests that the correct lyrics are retreived when given the song name and artist name.
    /// This function uses the Lyric-Plus API.
    /// If this test fails, please try a manual test with Postman using the following request: https://lyrics-plus.p.rapidapi.com/lyrics/April+Lady/queen
    /// to ensure the Lyrics-Plus API is responding correctly.
    /// </summary>
    /// <returns></returns>
    [Test]
    public async Task AssertLyricsRetreivedUsingLyricsPlusAPI()
    {
        var artistName = "queen";
        var songName = "April Lady";
        var expectedLyrics = "She won our hearts the arts she loved\nIs painting pictures for free\nWhen she was done she hung them up\nFor all the children to see\n\nGoodbye April lady\nIt's been good to have you around\nGoodbye April lady\nYou've done a lot for the folks in this town\n\nThe children learned to read\nShe strung their beads\nIt's sorry she was the one\nAs you can see isn't she good\nShe don't leave nothing undone\n\nGoodbye April lady\nIt's been good to have you around\nGoodbye April lady\nYou've done a lot for the folks in this town\n\nShe taught them all to love\nShe was their cream\nAnd we don't want her to go\nBut we know too well\nShe fell in love\nAnd there's no stopping her so\n\nGoodbye April lady\nIt's been good to have you around\nGoodbye April lady\nYou've done a lot for the folks in this town\n\nGoodbye April lady.  ";
        Communications comms = new();

        var lyricsForApriLady = await comms.GetLyricsForSong(songName, artistName);
        Assert.That(lyricsForApriLady, Is.EqualTo(expectedLyrics));
    }

}

