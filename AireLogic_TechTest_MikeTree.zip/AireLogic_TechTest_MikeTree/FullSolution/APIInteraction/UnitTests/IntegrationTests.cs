﻿using APIInteraction;

namespace Tests
{
    /// <summary>
    /// Integration tests - Cover more than one function. Testing how they integrate with one another.
    /// </summary>
    [TestFixture]
    public class IntegrationTests
    {
        [SetUp]
        public void Setup()
        {

        }

        /// <summary>
        /// Full end-to-end integration test. Checks that the correct average word count is obtained
        /// when given an artist name. 
        /// </summary>
        [Test]
        public async Task GetAverageWordCountForGivenArtist()
        {
            var artistName = "adele";
            WordCounter wCounter = new();
            var avgWordCount = await wCounter.GetAverageWordCountForArtistAsync(artistName);
            Assert.That(avgWordCount, Is.EqualTo(265));
        }
    }
}

