﻿using APIInteraction;

namespace UnitTests;

/// <summary>
/// Class containing unit tests that relate to the handling of text.
/// </summary>
[TestFixture]
public class TextHandlingUnitTests
{
    [SetUp]
    public void Setup()
    {
        
    }

    /// <summary>
    /// Ensure word counting is working as expected.
    /// </summary>
    [Test]
    public void CountAllWords()
    {
        var sampleText = "\rShe won our hearts the arts she loved\nIs painting pictures for free\nWhen she was done \rshe hung them up\nFor all the children to see\n\nGoodbye\rApril lady\nIt's been good to have you around\nGoodbye April lady\nYou've done a lot for the folks in this town\n\nThe children learned to read\nShe strung their beads\nIt's sorry she was the one\nAs you can see isn't she good\nShe don't leave nothing undone\n\nGoodbye April lady\nIt's been good to have you around\nGoodbye April lady\nYou've done a lot for the folks in this town\n\nShe taught them all to love\nShe was their cream\nAnd we don't want her to go\nBut we know too well\nShe fell in love\nAnd there's no stopping her so\n\nGoodbye April lady\nIt's been good to have you around\nGoodbye April lady\nYou've done a lot for the folks in this town\n\nGoodbye April lady Words and music by roger taylor\n\nThey were talking in whispers\nIn bear skins and fur\nCaptain scott and his heroes to be\nTo have laboured so long\nTo have made it this far\nOoh it's been such a long ride\nOoh you know it's been a long way\nFor a human human human\nFor a human body you see\nCan you believe it happens?\nNow it happens here\nDo you believe do you believe or really care\nCan you believe it happens?\nNow it happens here\nTo a human human\nWith a human body you see\n\nThere ain't nobody gets out of this moonlight\nToday is surprisingly fair\nOh oh oh oh woo woo\n\nWe've got problems the lone ranger can't fix\nThe invisible man couldn't see\nIt takes a tough guy\nTo learn some new tricks\nOoh it takes such a long time\nOoh it's been such a long way\nFor a human human human\nFor a human body you see\nCan you believe it happens?\nNow it happens here\nDo you believe do you believe or really care\nCan you believe it happens?\nNow it happens here\nTo a human human\nWith a human body you see\n\nYou know it's been such a long while\nIt's been such a long while\nTakes such a long time\nIt takes such a long time\nIt's been such a long way\nBeen such a long way\nIt's been such a long while\nBeen such a long while\nYeah yeah yeah yeah yeah yeah!\nIt's gonna be a long ride";
        WordCounter wordCounter = new();
        wordCounter.AllLyrics = sampleText;
        wordCounter.CountWords();
        Assert.That(wordCounter.WordCount, Is.EqualTo(417));
    }
}
