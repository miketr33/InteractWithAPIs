﻿using APIInteraction;

/// <summary>
/// Author: Mike Tree
/// Email: mikejtree@me.com
/// Written 2022 using .Net 6
/// </summary>

Console.WriteLine("*** Interact with APIs Tech Test submission my Mike Tree (mikejtree@me.com) ***" +
    "\nThis application allows you, the user to enter a music artists name and get back" +
    "\nthe average number of words per song they have written. This result will be" +
    "\ndisplayed in this console window after you have entered an artist name and" +
    "\npressed enter.\n" +
    "\nAs a stretch goal I have decided to use an alternative API to get lyrics. " +
    "\nThe lyrics-plus API is licensed via RapidAPI on the FREE subscription tier." +
    "\nThis API is much quicker at returning the lyrics, however as it is on the free" +
    "\nplan it has a hard limit of 200 requests per month. Therefore I have restricted" +
    "\nthe number of requests made to 5 in a given calculation. This can be modified in " +
    "\nthe Communications.cs file if you wish to achieve greater accuracy. You can also " +
    "\nsubscribe to a higher tier and replace the API key if you wish to not be limited." +
    "\nMore info available at: https://rapidapi.com/OsamaHu1277/api/lyrics-plus\n" +
    "\nFor testing I would recommend using a well know singer such as Adele.\n");
Console.WriteLine("To search for an average word count, please type in an artist name and press enter when done.");
var artistName = Console.ReadLine();

if (artistName != null)
{
    WordCounter wCounter = new();
    var avgWordCount = await wCounter.GetAverageWordCountForArtistAsync(artistName);
    Console.WriteLine($"Average word count for {artistName} is: {avgWordCount}");
    Console.ReadLine(); // Used to keep the result on screen.
}
else
{
    Console.WriteLine("Artist name invalid. Please try with a different artist name.");
}


