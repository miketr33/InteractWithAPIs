﻿using System;

namespace APIInteraction
{
    public  class WordCounter
    {
        #region Properties
        /// <summary>
        /// All the lyrics as one string block. This can be comprised of multple songs.
        /// </summary>
        public string AllLyrics { get; set; }

        /// <summary>
        /// The number of releases(musical works) that are included int he AllLyrics block.
        /// </summary>
        public int NumOfReleases { get; set; }

        /// <summary>
        /// The word count for a given string.
        /// </summary>
        public int WordCount { get; set; }

        /// <summary>
        /// The average word count for a given artist.
        /// </summary>
        public int AvgWordCount { get; set; }
        #endregion

        #region Constructor
        public WordCounter()
        {
            AllLyrics = "";
            NumOfReleases = 0;
            WordCount = 0;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Cleans the stored lyrics in this instance by removing \n and \r characters.
        /// </summary>
        private void CleanAllLyrics()
        {
            AllLyrics = AllLyrics.Replace("\n", " ").Replace("\r", " ");
        }

        /// <summary>
        /// Gets the number of words in a given body of text. Skips through whitespace etc
        /// Note: This code uses an adaptation of https://stackoverflow.com/questions/8784517/counting-number-of-words-in-c-sharp
        /// </summary>
        public void CountWords()
        {
            Console.WriteLine("Counting total words for all lyrics found...");
            int index = 0;
            int textLength = AllLyrics.Length;

            // Clean text
            CleanAllLyrics();

            if (textLength > 0)
            {
                // skip white space until first word
                while (index < textLength && char.IsWhiteSpace(AllLyrics[index]))
                    index++;

                while (index < textLength)
                {
                    while (index < textLength && !char.IsWhiteSpace(AllLyrics[index]))
                        index++;

                    WordCount++;

                    while (index < textLength && char.IsWhiteSpace(AllLyrics[index]))
                        index++;
                }
            }
        }

        /// <summary>
        /// Calculates the average word count by dividing the total word count by the number or releases.
        /// </summary>
        /// <returns>Average Word Count</returns>
        public int CalculateAvgWordCount()
        {
            CountWords();
            return WordCount > 0 && NumOfReleases > 0 ? WordCount / NumOfReleases : 0;
        }

        /// <summary>
        /// Gets the average word count for a given artist.
        /// </summary>
        /// <param name="artistName">The name of the artist you wish to get the average word count for.</param>
        /// <returns><see cref="int"/> of the average word count (to the nearest whole number)</returns>
        public async Task<int> GetAverageWordCountForArtistAsync(string artistName)
        {
            Communications comms = new();
            if (artistName != null)
            {
                var id = await comms.GetArtistId(artistName);
                if (id != null)
                {
                    Console.WriteLine($"Artist ID found!: {id}");
                    List<string> releases = new();
                    releases = await comms.GetWorksByArtistId(id);

                    int count = 0;
                    foreach (var song in releases)
                    {
                        if (count < comms.LyricApiLimit)
                        {
                            var lyrics = await comms.GetLyricsForSong(song, artistName);
                            if (!String.IsNullOrEmpty(lyrics))
                            {
                                AllLyrics += lyrics;
                                NumOfReleases++;
                            }

                            count++;
                        }
                        else
                        {
                            break;
                        }
                    }

                    if (NumOfReleases > 0)
                    {
                        AvgWordCount = CalculateAvgWordCount();
                        return AvgWordCount;
                    }
                    else
                    {
                        Console.WriteLine($"Lyrics not found for any of the releases checked. You may need to increase the limit");
                        return 0;
                    }

                }
            }
            return 0;
        }

        #endregion
    }
}

