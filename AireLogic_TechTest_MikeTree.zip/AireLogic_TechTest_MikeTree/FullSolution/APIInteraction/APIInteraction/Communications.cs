﻿using System;
using Newtonsoft.Json.Linq;

// Tests to write:
// Test correc artist id is returned: "b10bbbfc-cf9e-42e0-be17-e2c3e1d2600d for the beatles

namespace APIInteraction

{
    /// <summary>
    /// This class is used to communicate with various APIs using HttpClients. 
    /// </summary>
    public class Communications
    {
        #region Properties

        /// <summary>
        /// Limit for how many requests can be sent to the Lyric collecting API per execution of the GetLyricsForSong method.
        /// </summary>
        public int LyricApiLimit { get; set; } = 5;

        /// <summary>
        /// HttpClient used for communication with the MusicBrainz api. Info: https://musicbrainz.org/doc/MusicBrainz_API
        /// </summary>
        public HttpClient MusicBrainzClient { get; set; }

        /// <summary>
        /// HttpClient used for communication with the Lyrics-Plus api. Info: https://rapidapi.com/OsamaHu1277/api/lyrics-plus
        /// Note: The example uses the free subscription of the api which has a hard limit of 200 per month.
        /// To increase this limit (all the way up to 20,000 per day), you can opt for a paid subscription.
        /// Subscription info: https://rapidapi.com/OsamaHu1277/api/lyrics-plus/pricing
        /// </summary>
        public HttpClient LyricsPlusClient { get; set; }
        #endregion

        #region Constructor
        public Communications()
        {
            MusicBrainzClient = new HttpClient
            {
                BaseAddress = new Uri("http://musicbrainz.org/ws/2/")
            };
            MusicBrainzClient.DefaultRequestHeaders.Add("User-Agent", "MTArtistFinder/0.1 (mikejtree@gmail.com)"); // To avoid rate limiting

            // Create and configure LyricsPlusClient
            LyricsPlusClient = new HttpClient
            {
                BaseAddress = new Uri("https://lyrics-plus.p.rapidapi.com/lyrics/")
            };
            LyricsPlusClient.DefaultRequestHeaders.Add("User-Agent", "MTArtistFinder/0.1 (mikejtree@gmail.com)"); // To avoid rate limiting
            LyricsPlusClient.DefaultRequestHeaders.Add("X-RapidAPI-Host", "lyrics-plus.p.rapidapi.com"); // Host
            LyricsPlusClient.DefaultRequestHeaders.Add("X-RapidAPI-Key", "501fb595d6mshc08c130aef8e873p1f2704jsn6a73e838c845");   // RapidAPI key - Replace this if you change tier

        }
        #endregion

        #region Methods
        /// <summary>
        /// Gets the artist ID for a given ID using the MusicBrainz API (https://musicbrainz.org)
        /// </summary>
        /// <returns></returns> 
        public async Task<Guid?> GetArtistId(string artistName)
        {
            try
            {
                Console.WriteLine($"Getting artist ID for {artistName}");

                string formattedArtistName = ReplaceSpacesWithHexValue(artistName);
                var request = new HttpRequestMessage(HttpMethod.Get, requestUri: $"artist/?query=artist:{formattedArtistName}&limit=1&fmt=json");

                using var response = await MusicBrainzClient.SendAsync(request);
                _ = response.EnsureSuccessStatusCode();
                var body = response.Content.ReadAsStringAsync().Result;

                JObject o = JObject.Parse(body);
                Guid? artistId = (Guid?)o.SelectToken("artists[0].id");

                if (artistId != null)
                {
                    Console.WriteLine($"{artistName} has ID: {artistId}");
                    return artistId;
                }
                else
                {
                    Console.WriteLine("Failed to get artist ID.");
                    return null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: Failed to get ID from JSON: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Used to retrieve musical works by an artist, specified by artistId
        /// </summary>
        /// <param name="artistId">The <see cref="Guid"/> associated with a given artist</param>
        /// <returns>A list of song names associated with an artist.</returns>
        public async Task<List<string>> GetWorksByArtistId(Guid? artistId) 
        {
            List<string> releases = new();
            try
            {
                Console.WriteLine("Retrieving musical works....");
                var request = new HttpRequestMessage(HttpMethod.Get, requestUri: $"work?artist={artistId}&fmt=json");

                using var response = await MusicBrainzClient.SendAsync(request);
                _ = response.EnsureSuccessStatusCode();
                var body = response.Content.ReadAsStringAsync().Result;

                JObject o = JObject.Parse(body);

                int songCount = 0;
                foreach (JProperty property in o.Properties())
                {
                    if (property.Name.Equals("work-count"))
                    {
                        songCount = (int)property.Value;
                    }
                }

                foreach (JProperty property in o.Properties())
                {
                    if (property.Name.Equals("works"))
                    {
                        for (int i = 0; i < songCount; i++)
                        {
                            string? type = (string?)o.SelectToken($"works[{i}].type");
                            if (type != null)
                            {
                                if (type.Equals("Song"))
                                {
                                    string? title = (string?)o.SelectToken($"works[{i}].title");
                                    if (title != null)
                                    {
                                        releases.Add(title);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                Console.WriteLine($"Error: Failed to get releases for artist id {artistId}");
            }
            return releases;
        }


        /// <summary>
        /// Gets lyrics for a given song.
        /// The API used in this method is far quicker than lyricsovh however in order to make a reasonable
        /// number of requests (over 200 per month) payment is required. Therefore only sampling 5 songs to
        /// enable multiple tests at this stage.
        /// </summary>
        /// <param name="songName">The name of the song you wish to get lyrics for</param>
        /// <param name="artistName">The name of the artist who wrote the song</param>
        /// <returns>The lyrics as a <see cref="string"/></returns>
        public async Task<string> GetLyricsForSong(string songName, string artistName)
        {
            Console.WriteLine($"Getting lyrics for {songName} by {artistName}");

            string formattedSongName = ReplaceSpacesWithHexValue(songName);
            string formattedArtistName = ReplaceSpacesWithHexValue(artistName);
            string? lyrics = string.Empty;

            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, $"{formattedSongName}/{formattedArtistName}");

                using var response = await LyricsPlusClient.SendAsync(request);
                _ = response.EnsureSuccessStatusCode();
                var body = await response.Content.ReadAsStringAsync();

                JObject o = JObject.Parse(body);
                lyrics = (string?)o.SelectToken("lyrics");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: Failed to get ID from JSON: {ex.Message}");
                return "";
            }

            return lyrics != null ? lyrics : string.Empty;
        }
            
        /// <summary>
        /// Formats text to replace spaces with + for URLs
        /// </summary>
        /// <param name="stringToFormat">The string to format</param>
        /// <returns>The formatted string</returns>
        private static string ReplaceSpacesWithHexValue(string stringToFormat)
        {
            return stringToFormat.Replace(" ", "+");
        }

        #endregion

    }
}
